package com.example.ctp15.musicplayer;

import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Environment;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;

public class MusicService extends Service {
    public static MediaPlayer mp = new MediaPlayer();
    private IBinder mBinder =  new MyBinder();
    private Boolean isChoose;
    private long currentAnimator;
    public Bitmap bitmap;
    public String title;
    public String musician;


    @Override
    public final IBinder onBind(Intent intent) {
        return mBinder;
    }

    public MusicService() {
        try {
            mp.setDataSource(Environment.getExternalStorageDirectory() + "/data/山高水长.mp3");
            mp.prepare();
            mp.setLooping(true);
            isChoose = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void pauseOrStart() {
        if (mp.isPlaying()) {
            mp.pause();
        } else {
            mp.start();
        }
    }

    public void stop() {
        if (mp != null) {
            mp.stop();
            try {
                mp.prepare();
                mp.seekTo(0);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void setNewSong(String t, String m, Bitmap img) {
        title = t;
        musician = m;
        bitmap = img;
        isChoose = true;
    }

    public boolean isChoose() {
        return isChoose;
    }

    public void setCurrentAnimator(long t) {
        currentAnimator = t;
    }

    public long getCurrentAnimator() {
        return currentAnimator;
    }

    public class MyBinder extends Binder {
        MusicService getService() {
            return MusicService.this;
        }
    }

}
