package com.example.ctp15.musicplayer;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.animation.LinearInterpolator;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    private SimpleDateFormat time = new SimpleDateFormat("mm:ss");
    private MusicService ms;
    private IBinder mBinder;

    private ImageButton start;
    private CircleImageView disk_image;
    private SeekBar seekBar;
    private TextView time_pass;
    private TextView time_all;
    private TextView title;
    private TextView musician;
    private ObjectAnimator animator;
    String filePath;

    boolean hasPermission = false;
    boolean isRun = false;
    boolean aniStart = false;

    //实例化ServiceConnection
    private ServiceConnection sc = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            ms = ((MusicService.MyBinder)iBinder).getService();
            String totalTime = time.format(new Date(ms.mp.getDuration() + 0));
            time_all.setText(totalTime);

            animator.setCurrentPlayTime(ms.getCurrentAnimator());
            if(ms.mp.isPlaying()) {
                animator.start();
                aniStart = true;
                start.setImageResource(R.mipmap.pause);
            }

            if(ms.isChoose() == true) {
                title.setText(ms.title);
                musician.setText(ms.musician);
                disk_image.setImageBitmap(ms.bitmap);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            ms = null;
        }
    };

    //实例化Handler
    public Handler handler = new Handler();
    public Runnable runnable = new Runnable() {
        @Override
        public void run() {
            time_pass.setText(time.format(ms.mp.getCurrentPosition()));
            seekBar.setProgress(ms.mp.getCurrentPosition());
            seekBar.setMax(ms.mp.getDuration());
            time_all.setText(time.format(ms.mp.getDuration()));
            handler.postDelayed(runnable, 200);

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //获取权限
        getStoragePermission();

        start = findViewById(R.id.start);
        disk_image = findViewById(R.id.disk_image);
        seekBar = findViewById(R.id.seekBar);
        time_pass = findViewById(R.id.time_pass);
        time_all = findViewById(R.id.time_all);
        title = findViewById(R.id.title);
        musician = findViewById(R.id.musician);



        //启动Service
        Intent intent = new Intent(this, MusicService.class);
        startService(intent);
        //绑定Service
        bindService(intent, sc, BIND_AUTO_CREATE);

        if(isRun == false) {
            handler.post(runnable);
            isRun = true;
        }

        //旋转动画
        animator = ObjectAnimator.ofFloat(disk_image, "rotation", 0f, 360.0f);
        animator.setDuration(20000);//动画时间
        animator.setInterpolator(new LinearInterpolator());//动画插值
        animator.setRepeatCount(-1);//设置动画重复次数


        //进度条监听
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // nothing
            }

            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if(b == true) {
                    ms.mp.seekTo(i);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // nothing
            }
        });

    }



    void open_file(android.view.View target) {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("audio/*"); //选择音频
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == Activity.RESULT_OK) {
            Uri uri = data.getData();

            try {
                ms.mp.reset();
                ms.mp.setDataSource(this, uri);
                ms.mp.prepare();
                ms.mp.setLooping(true);

                MediaMetadataRetriever mmr = new MediaMetadataRetriever();
                mmr.setDataSource(this, uri);
                String newTitle = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
                String newMusician = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
                title.setText(newTitle);
                musician.setText(newMusician);

                byte[] p = mmr.getEmbeddedPicture();
                Bitmap bitmap = BitmapFactory.decodeByteArray(p, 0, p.length);
                disk_image.setImageBitmap(bitmap);

                seekBar.setProgress(0);
                start.setImageResource(R.mipmap.play);
                animator.pause();
                animator.setCurrentPlayTime(0);

                ms.setNewSong(newTitle, newMusician, bitmap);

                mmr.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    void start_and_pause(android.view.View target) {
        if (ms.mp.isPlaying()) {
            start.setImageResource(R.mipmap.play);
            animator.pause();
        } else {
            start.setImageResource(R.mipmap.pause);
            if(aniStart == false) {
                animator.start();
                aniStart = true;
            } else {
                animator.resume();
            }
        }
        ms.pauseOrStart();
    }



    void stop(android.view.View target) {
        start.setImageResource(R.mipmap.play);
        seekBar.setProgress(0);
        ms.stop();
        animator.pause();
        animator.setCurrentPlayTime(0);
    }



    void back(android.view.View target) {
        handler.removeCallbacks(runnable);
        unbindService(sc);
        sc = null;
        try {
            MainActivity.this.finish();
            System.exit(0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    private void getStoragePermission() {
        try {
            int permission = ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE);
            if (permission != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{ Manifest.permission.READ_EXTERNAL_STORAGE }, 1);
            } else {
                hasPermission = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode,KeyEvent event){
        if (keyCode== KeyEvent.KEYCODE_BACK) {
            ms.setCurrentAnimator(animator.getCurrentPlayTime());
            finish();
        }
        return false;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            hasPermission = true;
        } else {
            System.exit(0);
        }
        return;
    }

}
