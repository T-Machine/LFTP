g++ main.cpp Blend.cpp Feature.cpp FileReading.cpp Interpolation.cpp Projection.cpp Stitching.cpp Warping.cpp Match.cpp vl/sift.c vl/generic.c vl/host.c vl/random.c vl/imopv.c vl/mathop.c vl/kdtree.c -o e -lgdi32

./e